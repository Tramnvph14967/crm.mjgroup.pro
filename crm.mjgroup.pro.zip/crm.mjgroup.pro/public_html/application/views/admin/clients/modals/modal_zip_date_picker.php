<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php echo render_date_input('zip-from','zip_from_date'); ?>
<?php echo render_date_input('zip-to','zip_to_date'); ?>
